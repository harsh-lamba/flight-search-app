import { IFlight, FlightEntityModel } from "./Flight.EntityModel";

export { IFlight, FlightEntityModel as FlightModel };
